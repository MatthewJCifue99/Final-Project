class Item{
  //Fill in the item class below this comment.
  constructor (n ,p, s){
    this.name= n;
    this.price= p;
    this.shipping= s;
  }



}

//Create your three test items below this comment.
